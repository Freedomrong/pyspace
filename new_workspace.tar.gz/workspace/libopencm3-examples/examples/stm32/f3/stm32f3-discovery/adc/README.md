# README

This is the smallest-possible example program using libopencm3.

It's intended for the ST STM32F3DISCOVERY eval board. It should read from the
`ADC1_IN1 (PA0)` pin its voltage and print it in the LEDs.


