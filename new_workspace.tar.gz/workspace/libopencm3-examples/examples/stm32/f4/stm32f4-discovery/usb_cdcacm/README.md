# README

This example implements a USB CDC-ACM device (aka Virtual Serial Port)
to demonstrate the use of the USB device stack.

## Board connections

| Port  | Function       | Description                               |
| ----- | -------------- | ----------------------------------------- |
| `CN5` | `(USB_OTG_FS)` | USB acting as device, connect to computer |
