# README

This example implements a USB CDC-ACM device (aka Virtual Serial Port) to
demonstrate the use of the USB device stack.

