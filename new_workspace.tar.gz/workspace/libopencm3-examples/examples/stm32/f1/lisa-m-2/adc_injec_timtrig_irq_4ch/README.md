# README

This is a simple example that sends the values read out from four ADC
channels of the STM32 to the USART2.

This example uses a timer trigger to sample the injected adc channels and
then uses an interrupt routine to retrieve the samples from the data registers.

The terminal settings for the receiving device/PC are 115200 8n1.

