# README

This is a simple polling example that sends the value read out from the
temperature sensor ADC channel of the STM32 to the USART2.

The terminal settings for the receiving device/PC are 115200 8n1.

