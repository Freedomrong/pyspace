# simple-gcc-stm32-project

这是一个我在一开始学习在ubuntu下编程使用的工程，
是使用CooCox的启动文件和原子例程序改写的，其功能是使原
子开发板上的一个LED灯闪烁。该工程的学习与使用教程请参考我的
博客：

> http://blog.csdn.net/zhengyangliu123
