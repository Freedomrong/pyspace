#include "led.h"
#include "delay.h"
#include "sys.h"
#include "pwm.h"
//ALIENTEK Mini STM32¿ª·¢°å·¶Àý´úÂë8
//PWMÊä³öÊµÑé
//¼¼ÊõÖ§³Ö£ºwww.openedv.com
//¹ãÖÝÊÐÐÇÒíµç×Ó¿Æ¼¼ÓÐÏÞ¹«Ë¾

 int main(void)
 {
	u16 led0pwmval=0;
	u8 dir=1;
	delay_init();	    	 //ÑÓÊ±º¯Êý³õÊ¼»¯
	LED_Init();		  	//³õÊ¼»¯ÓëLEDÁ¬½ÓµÄÓ²¼þ½Ó¿Ú
   	while(1)
	{
 		delay_ms(1000);
    LED0 = 0;
    LED1 = 1;
    delay_ms(1000);
    LED0 = 1;
    LED1 = 0;
	}
}
